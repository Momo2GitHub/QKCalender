using System;
namespace ThoughtWorks.QRCode.ExceptionHandler
{
	public class VersionInformationException:System.ArgumentException
	{
	}
}